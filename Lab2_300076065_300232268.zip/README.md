# Lab2
SEG 2106
By James Couture & Nathan Gawargy